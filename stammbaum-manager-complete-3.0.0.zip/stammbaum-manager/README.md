# Stammbaum Manager - Complete Edition

Ein umfassendes WordPress-Plugin für die Verwaltung von Tierzucht, Stammbäumen, Würfen, Welpen und Wartelisten.

## Features

### 🐕 Tier-Verwaltung
- Vollständige Stammbaum-Verwaltung mit Großeltern
- Genetik & Gesundheitstests
- Ausstellungserfolge
- Nachkommen-Galerie
- Profilbilder und Detailinformationen

### 👶 Welpen-Verwaltung
- Custom Post Type für Welpen
- Status-Verwaltung (Verfügbar, Reserviert, Verkauft)
- Verknüpfung mit Elterntieren und Würfen
- Galerie-Funktion
- WhatsApp-Integration
- Social Media Sharing

### 🐾 Wurf-Verwaltung
- Planung und Verwaltung von Würfen
- Verknüpfung mit Zuchttieren aus der Datenbank
- Erwartete und tatsächliche Wurfdaten
- Genetik- und Farbinformationen

### 📋 Wartelisten-Verwaltung
- Frontend-Anmeldeformulare
- Admin-Dashboard für Anmeldungen
- Status-Verwaltung (Ausstehend, Bestätigt, Abgelehnt)
- E-Mail-Benachrichtigungen
- Export-Funktion (CSV)

## Installation

1. Plugin-Ordner nach `/wp-content/plugins/` hochladen
2. Plugin im WordPress-Admin aktivieren
3. Menüpunkt "Stammbaum Manager" erscheint im Admin-Menü

## Datenbank-Struktur

Das Plugin erstellt folgende Tabellen:
- `stammbaum_animals` - Haupttabelle für alle Tiere
- `stammbaum_genetics` - Genetik & Gesundheitstests
- `stammbaum_achievements` - Ausstellungserfolge
- `stammbaum_offspring_gallery` - Nachkommen-Galerie
- `stammbaum_additional_info` - Zusätzliche Informationen
- `breeding_litters` - Würfe
- `breeding_applications` - Wartelisten-Anmeldungen

## Shortcodes

### Stammbaum
```
[stammbaum id="1"]
```

### Tier-Profil
```
[stammbaum_profil id="1"]
```

### Tier-Galerie
```
[stammbaum_galerie type="breeding" limit="12"]
```

### Welpen-Liste
```
[welpen_liste status="verfugbar" limit="12"]
```

### Wurf-Liste
```
[breeding_litters status="active" limit="10"]
```

### Wartelisten-Formular
```
[breeding_waitlist litter_id="1"]
```

### WhatsApp-Button
```
[whatsapp_button text="Kontakt" message="Hallo!"]
```

## Berechtigungen

Das Plugin fügt folgende Berechtigungen hinzu:
- `manage_stammbaum` - Tier-Verwaltung
- `manage_breeding` - Wurf- und Wartelisten-Verwaltung
- `manage_puppies` - Welpen-Verwaltung

## Einstellungen

Unter "Stammbaum Manager → Einstellungen" können folgende Optionen konfiguriert werden:
- E-Mail-Benachrichtigungen
- Maximale Anzahl Wartelisten-Anmeldungen
- WhatsApp-Integration
- Social Media Sharing
- Favoriten-Funktion
- Währung und Symbol

## Kompatibilität

- WordPress 5.0+
- PHP 7.4+
- Kompatibel mit allen gängigen Themes

## Migration von alten Plugins

Dieses Plugin ist vollständig kompatibel mit den Datenbanktabellen der folgenden Plugins:
- Breeding Waitlist Manager
- Stammbaum Manager Pro 2.0
- Welpen Management Pro

Bestehende Daten bleiben erhalten und werden automatisch verknüpft.

## Support

Bei Fragen oder Problemen wenden Sie sich bitte an den Plugin-Entwickler.

## Version

3.0.0 - Complete Edition

## Lizenz

GPL v2 or later
